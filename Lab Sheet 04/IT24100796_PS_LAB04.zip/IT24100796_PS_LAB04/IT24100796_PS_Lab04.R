setwd("C:\\Users\\IT24100796\\Desktop\\IT24100796")
Branch_data <- read.table("Exercise.txt", header = TRUE, sep =",")
fix(Branch_data)
attach(Branch_data)
str(Branch_data)
boxplot(Sales_X1, main="Boxplot for sales", outline=TRUE, outpch=8,horizontal = TRUE)
summary(Advertising_X2)
quantile(Advertising_X2)
IQR(Advertising_X2)
get.outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3-q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("upper bound =", ub))
  print(paste("Lower bound =", lb))
  print(paste("Outliers:", paste(sort(z[z < lb | z > ub]),collapse =", ")))
}

get.outliers(Years_X3)